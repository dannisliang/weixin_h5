"How to Use Steps() in CSS Animations" is licensed under a Creative Commons Attribution 3.0 Unported (CC BY 3.0)  (http://creativecommons.org/licenses/by/3.0/). 

You are allowed to use these freebie anywhere you want, however we’ll highly appreciate if you will link to our website when you share them - http://designmodo.com

Thanks for supporting our website and enjoy!

Links:
http://designmodo.com/steps-css-animations/